from collections import deque

def bfs(graph, start):
    visited = set()  # Keep track of visited nodes
    order_of_visit = []  # To store the order of visited nodes
    
    queue = deque([start])  # Use a queue to explore the nodes
    visited.add(start)

    while queue:
        node = queue.popleft()  # Remove the node from the queue
        order_of_visit.append(node)  # Append the node to the visit order

        # Explore all neighbors of the current node
        for neighbor in range(len(graph)):
            if graph[node][neighbor] == 1 and neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)

    return order_of_visit


graph = [
    [0, 1, 1, 0, 0, 0],  # A
    [1, 0, 0, 1, 1, 0],  # B
    [1, 0, 0, 0, 0, 1],  # C
    [0, 1, 0, 0, 0, 0],  # D
    [0, 1, 0, 0, 0, 1],  # E
    [0, 0, 1, 0, 1, 0],  # F
]

start_node_bfs = 0  
bfs_result = bfs(graph, start_node_bfs)

print(f"BFS traversal : {bfs_result}")


# Example adjacency matrix (undirected)
# The matrix represents the following graph:
# A - B, 
# A - C, 
# B - D, 
# B - E, 
# C - F, 
# E - F