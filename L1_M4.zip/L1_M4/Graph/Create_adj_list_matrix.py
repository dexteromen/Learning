def create_adj_list(V,edges):
    adj_list ={}
    for v in range(V):
        adj_list[v] = []

    for e in edges:
        u,v = e
        adj_list[u].append(v)
        adj_list[v].append(u)
    return adj_list

def creatre_adj_matrix(V,edges):
    adj_matrix = [[0]*V for _ in range(V)]
    for e in edges:
        u,v = e
        adj_matrix[u][v] = 1
        adj_matrix[v][u] = 1
    return adj_matrix


def print_adj_list(adj_list):
    for key in adj_list:
        print(key, ":", adj_list[key])

def print_adj_matrix(adj_matrix):
    for row in adj_matrix:
        print(row)

# if __name__ == "__main__":
#     V = 8
#     edges = [(0,1),(0,2),(0,3),(1,4),(1,5),(2,6),(3,7)] 
#     startNode = 0

#     #CREATING ADJACENCY LIST
#     adj_list = create_adj_list(V,edges)
#     print_adj_list(adj_list)

#     print()
    
#     #CREATING ADJACENCY MATRIX
#     adj_matrix = creatre_adj_matrix(V,edges)
#     print_adj_matrix(adj_matrix)

#     # #PRINTING BFS TRAVERSAL
#     # print("BFS Traversal:")
#     # bfs(adj_list,0)
#     # print()

#     # #PRINTING DFS TRAVERSAL
#     # print("DFS Traversal:")
#     # visited = [False] * V
#     # dfs_rec(adj_list, visited, 0)
#     # print()
