class State():
    def __init__(self, cl, ml, boat, cr, mr):
        self.cl = cl  # Cannibals on the left
        self.ml = ml  # Missionaries on the left
        self.boat = boat  # Position of the boat ('left' or 'right')
        self.cr = cr  # Cannibals on the right
        self.mr = mr  # Missionaries on the right
        self.parent = None

    def is_goal(self):
        # Goal is when all missionaries and cannibals are on the right side
        if self.cr == 0 and self.mr == 0:
        # if self.cl == 0 and self.ml == 0:
            return True
        return False

    def is_valid(self):
        # Valid state checks
        if self.ml < 0 or self.mr < 0 or self.cl < 0 or self.cr < 0:
            return False  # Cannot have negative numbers of people
        if (self.ml == 0 or self.ml >= self.cl) and (self.mr == 0 or self.mr >= self.cr):
            return True  # Valid configuration: missionaries are not outnumbered by cannibals
        return False

    def __eq__(self, other):
        # Check if two states are equal by comparing their attributes
        return self.cl == other.cl and self.ml == other.ml \
               and self.boat == other.boat and self.cr == other.cr \
               and self.mr == other.mr

    def __hash__(self):
        # Generate a unique hash value for the state based on its attributes
        return hash((self.cl, self.ml, self.boat, self.cr, self.mr))

def successors(cur_state):
    children = []
    moves = [
        (-2, 0),  # Two missionaries cross
        (0, -2),  # Two cannibals cross
        (-1, -1), # One missionary and one cannibal cross
        (0, -1),  # One missionary crosses
        (-1, 0),  # One cannibal crosses
    ]
    
    if cur_state.boat == 'left':
        # Moving from left to right
        for m, c in moves:
            new_state = State(
                cur_state.cl + c, cur_state.ml + m, 'right', cur_state.cr - c, cur_state.mr - m
            )
            if new_state.is_valid():
                new_state.parent = cur_state
                children.append(new_state)
    else:
        # Moving from right to left
        for m, c in moves:
            new_state = State(
                cur_state.cl - c, cur_state.ml - m, 'left', cur_state.cr + c, cur_state.mr + m
            )
            if new_state.is_valid():
                new_state.parent = cur_state
                children.append(new_state)

    return children

def bfs():
    # Start state
    start = State(0, 0, 'right', 3, 3)
    # start = State(3, 3, 'left', 0, 0)
    
    # Check if the start state is valid or already a solution
    if not start.is_valid():
        print("Start state is invalid.")
        return None
    if start.is_goal():
        return start
    
    queue = list()  # Queue to keep track of states to explore
    visited = set()  # Set to keep track of states already explored
    queue.append(start)

    while queue:
        state = queue.pop(0)  # Get the first state in the queue
        if state.is_goal():
            return state
        visited.add(state)  # Add the state to the visited set

        children = successors(state)  # Get the children of the current state
        
        for child in children: 
            if (child not in visited) and (child not in queue):  # Check if the child is not already visited or in the queue
                queue.append(child)

    return None  # If no solution is found

def print_solution(solution):
    path = []   
    path.append(solution)
    parent = solution.parent
    while parent:
        path.append(parent)
        parent = parent.parent

    for t in range(len(path)):
        state = path[len(path) - t - 1]
        boat_position = 'R' if state.boat == 'right' else 'L'
        print(f"({state.cl},{state.ml} , {boat_position} , {state.cr},{state.mr})")

def main():
    solution = bfs()
    if solution:
        print("Missionaries and Cannibals solution:")
        print("LEFT, BOAT, RIGHT")
        print(" C,M       C,M")
        print_solution(solution)
    else:
        print("No solution found.")

if __name__ == "__main__":
    main()