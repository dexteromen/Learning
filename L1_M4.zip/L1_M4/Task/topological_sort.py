# Topological sort.
# https://www.geeksforgeeks.org/topological-sorting/

def topologicalSortUtil(v, adj, visited, st):
    visited[v] = True   # Mark the current node as visited
    
    for i in adj[v]:    # Recur for all adjacent vertices
        if not visited[i]:
            topologicalSortUtil(i, adj, visited, st)
    
    st.append(v)    # Push current vertex to stack which stores the result

def topologicalSort(adj):
    V = len(adj) # Number of vertices    
    st = [] # Stack to store the result
    visited = [False] * V

    for i in range(V):     # Call the recursive helper function to store Topological Sort starting from all vertices one by one
        if not visited[i]:
            topologicalSortUtil(i, adj, visited, st)
    
    return st[::-1] # Append contents of stack and reverse it

if __name__ == "__main__":
    
    # Graph represented as an adjacency list
    # adj = [[],[],[3],[1],[0, 1],[0, 2]]
    adj = [[5],[0],[],[1,2],[2,5],[]]

    ans = topologicalSort(adj)
    
    print( "Topological Sort: ", end="")
    for i in range(len(ans)):
        print(ans[i], end=" ") 
    print()
