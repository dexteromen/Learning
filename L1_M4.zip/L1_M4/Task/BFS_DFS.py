from collections import deque

# Breadth-First Search (BFS)
def bfs(graph, start):
    visited = set()  # Keep track of visited nodes
    order_of_visit = []  # To store the order of visited nodes
    
    queue = deque([start])  # Use a queue to explore the nodes
    visited.add(start)

    while queue:
        node = queue.popleft()  # Remove the node from the queue
        order_of_visit.append(node)
        
        for neighbor in graph[node]:    # Explore all neighbors of the current node
            if neighbor not in visited:
                visited.add(neighbor)
                queue.append(neighbor)

    return order_of_visit

# Depth-First Search (DFS) using a stack
def dfs_stack(graph, start):
    visited = set()
    stack = [start]
    order_of_visit = []

    while stack:
        node = stack.pop()
        if node not in visited:
            visited.add(node)
            order_of_visit.append(node)

            for neighbor in reversed(graph[node]):  # Push neighbors to the stack (reverse the order for proper traversal)
                if neighbor not in visited:
                    stack.append(neighbor)

    return order_of_visit

# Depth-First Search (DFS) using recursion
def dfs(graph, start):
    visited = set()  # Keep track of visited nodes
    order_of_visit = []  # To store the order of visited nodes
    
    def dfs_recursive(node):
        visited.add(node)
        order_of_visit.append(node)
        
        for neighbor in graph[node]:    # Explore all neighbors of the current node
            if neighbor not in visited:
                dfs_recursive(neighbor)

    dfs_recursive(start) # Start DFS traversal
    return order_of_visit





graph_bfs = {
    'A': ['B', 'C'],
    'B': ['A', 'D', 'E'],
    'C': ['A', 'F'],
    'D': ['B'],
    'E': ['B', 'F'],
    'F': ['C', 'E']
}
graph_dfs = {
    'A': ['B', 'C'],
    'B': ['A', 'D', 'E'],
    'C': ['A', 'F'],
    'D': ['B'],
    'E': ['B', 'F'],
    'F': ['C', 'E']
}

# # Example usage of BFS
# start_node_bfs = 'A'

# bfs_result = bfs(graph_bfs, start_node_bfs)
# print(f"BFS traversal starting from {start_node_bfs}: {bfs_result}")


start_node_dfs = 'A'

dfs_result = dfs(graph_dfs, start_node_dfs)
print(f"DFS traversal starting from {start_node_dfs}: {dfs_result}")


dfs_stack_result = dfs_stack(graph_dfs, start_node_dfs)
print(f"Non-recursive DFS traversal starting from {start_node_dfs}: {dfs_stack_result}")