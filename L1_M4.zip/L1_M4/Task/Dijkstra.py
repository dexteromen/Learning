import heapq

def dijkstra(graph, start):
    # Create a priority queue for the vertices to explore, initialized with the start node
    queue = [(0, start)]  # (distance, node)
    
    # Initialize distances with infinity
    distances = {node: float('inf') for node in graph}
    distances[start] = 0
    
    # Store the previous node in the shortest path
    Parent = {node: None for node in graph}
    
    while queue:
        current_distance, curr_node = heapq.heappop(queue)  # Get the node with the smallest distance

        # If the distance of the current node is greater than the current known distance, skip it
        if current_distance > distances[curr_node]:
            continue
        
        # Explore each neighbor of the current node
        for adjNode, wt in graph[curr_node].items():
            distance = current_distance + wt
            
            # If a shorter path to the neighbor is found, update the distance and add to the priority queue
            if distance < distances[adjNode]:
                distances[adjNode] = distance
                Parent[adjNode] = curr_node
                heapq.heappush(queue, (distance, adjNode))
    
    return distances, Parent

def shortest_path(Parent, end):
    print("     Parent:   ",Parent)
    print()
    path = []
    curr_node = end
    while curr_node is not None:
        path.append(curr_node)
        curr_node = Parent[curr_node]
    return path[::-1]

# #Example graph and start/end nodes
# graph = {
#     'A': {'B': 1, 'C': 4},
#     'B': {'A': 1, 'C': 2, 'D': 5},
#     'C': {'A': 4, 'B': 2, 'D': 1},
#     'D': {'B': 5, 'C': 1}
# }
# start_node = 'A'
# end_node = 'D'

# node,weight
graph = {
    '0': {'1': 4, '2': 3},
    '1': {'3': 2, '2': 1, '0': 4},
    '2': {'0': 3, '1': 1, '3': 4},
    '3': {'1': 2, '4': 2, '2': 4},
    '4': {'3': 2, '5': 6},
    '5': {'4': 6}
}
start_node = '0'
end_node = '5'


# Run Dijkstra's algorithm
distances, Parent = dijkstra(graph, start_node)

# Output the shortest distance from start to each node
print("Shortest distances from start node:", distances)

# Get the shortest path from start to end
path = shortest_path(Parent, end_node)
print(f"The shortest path from {start_node} to {end_node} is:", path)
