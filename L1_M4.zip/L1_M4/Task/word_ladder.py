from collections import deque

class Solution:
    def wordLadderLength(self, startWord, targetWord, wordList):
        # Creating a queue ds of type {word, transitions to reach ‘word’}.
        q = deque([(startWord, 1)])

        # Push all values of wordList into a set
        # to make deletion from it easier and in less time complexity.
        wordSet = set(wordList)
        wordSet.discard(startWord)

        while q:
            word, steps = q.popleft()

            # We return the steps as soon as
            # the first occurrence of targetWord is found.
            if word == targetWord:
                return steps

            for i in range(len(word)):
                # Now, replace each character of ‘word’ with char
                # from a-z then check if ‘word’ exists in wordList.
                original = word[i]
                for ch in 'abcdefghijklmnopqrstuvwxyz':
                    word = word[:i] + ch + word[i+1:]
                    # check if it exists in the set and push it in the queue.
                    if word in wordSet:
                        wordSet.remove(word)
                        q.append((word, steps + 1))
                word = word[:i] + original + word[i+1:]

        # If there is no transformation sequence possible
        return 0

# Driver code
if __name__ == "__main__":
    startWord = "der"
    targetWord = "dfs"
    wordList = ["des", "der", "dfr", "dgt", "dfs"]

    s = Solution()
    print(s.wordLadderLength(startWord, targetWord, wordList))
